# Workshop Examples

Place workshop example files and folders here. These will be copied into the Docusaurus static assets during build so they can be viewed and downloaded.
