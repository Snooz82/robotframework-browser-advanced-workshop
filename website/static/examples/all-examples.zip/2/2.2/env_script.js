const number = 12
let adding = 2

console.log(add(number, adding));

adding = adding + 2

console.log(add(number, adding));

function add(a, b) {
    return a + b
}